import java.util.Random;

class Cavallo extends Thread {
    private String name;
    private int pathLength;
    private int distanceCovered = 0;
    private Random random = new Random();

    public Cavallo(String name, int pathLength) {
        this.name = name;
        this.pathLength = pathLength;
    }

    @Override
    public void run() {
        while (distanceCovered < pathLength) {
            int step = random.nextInt(10) + 1;
            distanceCovered += step;

            if (distanceCovered > pathLength) {
                distanceCovered = pathLength;
            }

            System.out.println(name + " ha percorso " + distanceCovered + " metri ");

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(name + " ha tagliato il traguardo!");
    }
}